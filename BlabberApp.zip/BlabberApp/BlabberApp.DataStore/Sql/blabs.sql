SELECT * FROM `donbstringham`.`blabs`;
SELECT * FROM `donbstringham`.`users`;
TRUNCATE `donbstringham`.`blabs`;
TRUNCATE `donbstringham`.`users`;