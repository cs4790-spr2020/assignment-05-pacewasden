﻿namespace BlabberApp.Domain.Interfaces
{
    public interface IBaseEntity
    {
        string getSysId();
    }
}
