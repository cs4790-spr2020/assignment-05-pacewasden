using System;
using BlabberApp.Domain.Entities;

namespace BlabberApp.Domain.Interfaces
{
    public interface IUserRepository : IRepository<User>
    {
    }
}