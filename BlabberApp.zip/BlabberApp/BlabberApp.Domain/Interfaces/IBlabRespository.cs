using System;
using BlabberApp.Domain.Entities;

namespace BlabberApp.Domain.Interfaces
{
    public interface IBlabRepository : IRepository<Blab>
    {
    }
}