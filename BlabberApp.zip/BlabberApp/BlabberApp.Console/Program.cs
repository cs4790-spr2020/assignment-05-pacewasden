﻿using Sys = System;

namespace BlabberApp.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Sys.Console.WriteLine("Hello from BlabberApp.Console");
        }
    }
}
