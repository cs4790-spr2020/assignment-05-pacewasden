using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BlabberApp.ClientTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
