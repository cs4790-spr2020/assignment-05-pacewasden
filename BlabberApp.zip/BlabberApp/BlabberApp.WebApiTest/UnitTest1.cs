using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BlabberApp.WebApiTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
